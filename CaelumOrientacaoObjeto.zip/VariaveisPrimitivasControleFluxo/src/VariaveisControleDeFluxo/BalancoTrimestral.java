package VariaveisControleDeFluxo;

public class BalancoTrimestral {

	public static void main(String[] args) {

		double gastoJaneiro = 1500;
		double gastoFevereiro = 2300;
		double gastoMarco = 1700;
		double gastoTrimesral = gastoJaneiro + gastoFevereiro + gastoMarco;
		double mediaMensal = gastoTrimesral / 3;
		// Uso do casting = int i = (int) mediaMensal;
		// Uso do float = float x = 1.1f;
		
		System.out.println("O valor gasto no m�s foi " + gastoTrimesral +
				" e a m�dia mensal foi " + mediaMensal);
	}

}
