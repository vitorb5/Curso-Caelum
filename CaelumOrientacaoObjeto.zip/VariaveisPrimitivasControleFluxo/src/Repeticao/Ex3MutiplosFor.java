package Repeticao;

public class Ex3MutiplosFor {
	public static void main(String[] args) {
		for (int i = 0; i < 100; i++) {
			if (i % 3 == 0) {
				System.out.println("Os n�mero divisiveis por 3 s�o " + i);
				
			}
		}
	}

}
