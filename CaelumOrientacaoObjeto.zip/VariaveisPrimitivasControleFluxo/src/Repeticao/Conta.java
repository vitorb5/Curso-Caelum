package Repeticao;

import java.util.Scanner;

public class Conta {
	public static void main(String[] args) {
		Scanner dig = new Scanner(System.in);
		System.out.println("Digite um n�mero: ");
		int x = dig.nextInt();
		if (x % 2 == 0) {
			x = x / 2;
			System.out.println("Par " + x);
		} else if (x % 3 == 0) {
			x = 3 * x + 1;
			System.out.println("Impar " + x);

		}
		{

		}

	}

}
