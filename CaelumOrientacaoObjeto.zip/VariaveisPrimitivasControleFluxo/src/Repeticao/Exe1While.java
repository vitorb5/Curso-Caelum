package Repeticao;

public class Exe1While {
	
	public static void main(String[] args) {
		int i = 150;
		while (i <= 300) {
			System.out.println(i);
			i++;
			
		}
	}

}
