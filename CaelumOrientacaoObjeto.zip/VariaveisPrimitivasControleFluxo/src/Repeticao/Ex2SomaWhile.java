package Repeticao;

public class Ex2SomaWhile {
	public static void main(String[] args) {
		int i = 1;
		while (i <1000) {
			i=i+i;			
			System.out.println(i);
		}
	}

}
