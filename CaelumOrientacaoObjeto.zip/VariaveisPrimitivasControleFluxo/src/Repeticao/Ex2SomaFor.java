package Repeticao;

public class Ex2SomaFor {
	public static void main(String[] args) {
		for (int i = 1; i < 1000; i=i+i) {
			System.out.println(i);
			
		}
	}

}
