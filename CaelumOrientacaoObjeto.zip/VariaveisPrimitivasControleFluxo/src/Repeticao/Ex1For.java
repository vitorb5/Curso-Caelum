package Repeticao;

public class Ex1For {
	public static void main(String[] args) {
		
		for (int j = 150; j <= 300; j++) {
			System.out.println(j);
			
		}
	}

}
