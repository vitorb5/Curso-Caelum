package Itau;

public class Conta {
		
	String conta;
	int numeroConta;
	String agencia;
	double saldo;
	String dataAbertura;
	
	boolean saca(double quantidade){
		if (saldo < quantidade) {
			System.out.println("N�o pode sacar");
			return false; 
		}else {
			System.out.println("Pode sacar");
		}
		return true;
	}
	

}

//   void acelera(double quantidade) {
//  double velocidadeNova = this.velocidadeAtual + quantidade; 
//this.velocidadeAtual = velocidadeNova;
//}